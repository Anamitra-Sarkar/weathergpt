# WeatherGPT Checker Report

{
  "M1": {
    "rows": 1500,
    "cols": [
      "raw_field",
      "canonical_variable",
      "statistic",
      "accumulation_hours",
      "source_hint"
    ],
    "dtypes": {
      "raw_field": "object",
      "canonical_variable": "object",
      "statistic": "object",
      "accumulation_hours": "float64",
      "source_hint": "object"
    },
    "missing": {
      "raw_field": 0,
      "canonical_variable": 0,
      "statistic": 0,
      "accumulation_hours": 1089,
      "source_hint": 0
    },
    "unique_raw": 231,
    "per_canonical": {
      "precipitation_amount": 411,
      "heavy_rain_warning": 262,
      "temperature_2m": 227,
      "wind_speed": 206,
      "precipitation_probability": 145,
      "precipitation_rate": 113,
      "wind_gust": 54,
      "temperature_min": 45,
      "temperature_max": 37
    },
    "per_stat": {
      "instant": 600,
      "accumulation": 411,
      "categorical": 262,
      "probability": 145,
      "min": 45,
      "max": 37
    },
    "dup_rows": 1269,
    "extra_labels_vs_expected_6": [
      "temperature_max",
      "temperature_min",
      "wind_gust"
    ],
    "missing_labels_vs_expected_6": [],
    "sample_TMAX_mm": 6,
    "needs_processing": [
      "dedup 1269 duplicates",
      "label_map mismatch: extra {'temperature_max', 'temperature_min', 'wind_gust'} -> expand LABEL_MAP to 8/9 or collapse",
      "class imbalance 411 vs 37 (tmax)",
      "fix TMAX (mm) unit error"
    ],
    "acc_hours": {
      "6.0": 411
    },
    "verdict": "NEEDS PROCESSING"
  },
  "M2": {
    "rows": 4800,
    "cols": [
      "lat",
      "lon",
      "elevation_m",
      "lead_hours",
      "valid_from",
      "gfs_t2m_k",
      "gfs_apcp_mm",
      "obs_t2m_c",
      "obs_apcp_mm"
    ],
    "dtypes": {
      "lat": "float64",
      "lon": "float64",
      "elevation_m": "int64",
      "lead_hours": "int64",
      "valid_from": "object",
      "gfs_t2m_k": "float64",
      "gfs_apcp_mm": "float64",
      "obs_t2m_c": "float64",
      "obs_apcp_mm": "float64"
    },
    "missing": {
      "lat": 0,
      "lon": 0,
      "elevation_m": 0,
      "lead_hours": 0,
      "valid_from": 0,
      "gfs_t2m_k": 0,
      "gfs_apcp_mm": 0,
      "obs_t2m_c": 0,
      "obs_apcp_mm": 0
    },
    "head": [
      {
        "lat": 21.14,
        "lon": 79.08,
        "elevation_m": 240,
        "lead_hours": 0,
        "valid_from": "2024-01-01T00:00",
        "gfs_t2m_k": 291.65,
        "gfs_apcp_mm": 0.0,
        "obs_t2m_c": 14.6,
        "obs_apcp_mm": 0.0
      },
      {
        "lat": 21.14,
        "lon": 79.08,
        "elevation_m": 240,
        "lead_hours": 1,
        "valid_from": "2024-01-01T01:00",
        "gfs_t2m_k": 290.95,
        "gfs_apcp_mm": 0.0,
        "obs_t2m_c": 14.7,
        "obs_apcp_mm": 0.0
      }
    ],
    "gfs_K_range": [
      271.65,
      306.04999999999995
    ],
    "obs_C_range": [
      -4.6,
      32.9
    ],
    "corr_t2m": 0.9604788197534391,
    "corr_precip": 0.4265201487462652,
    "elevation_unique": [
      6,
      9,
      14,
      45,
      53,
      55,
      98,
      216,
      240,
      298
    ],
    "lead_unique": [
      0,
      1,
      2,
      3,
      4,
      5,
      6,
      7,
      8,
      9
    ],
    "lead_is_sequential": true,
    "needs_processing": [
      "lead_hours 0-239 sequential is time-index not forecast lead; recompute as lead = valid - init (0-72)"
    ],
    "bias_t_mean": -1.411000000000011,
    "bias_t_std": 2.052777239416298,
    "verdict": "NEEDS PROCESSING"
  },
  "M3_error": "name 'ch' is not defined",
  "final_plan": {
    "M1": "Fix LABEL_MAP vs CSV (expand to 8 or collapse), dedup 100+, fix TMAX(mm), add acc hours 1,3,24, balance classes, then tokenization only",
    "M2": "Recompute lead_hours correctly, verify corr not 1.0, apply StandardScaler (fit train only), time-aware split 2024-01-01:07 -> train, 08:10 -> val, spatial hold-out 5 points, keep elevation scaling",
    "M3": "Ready",
    "env": "Force CPU"
  }
}